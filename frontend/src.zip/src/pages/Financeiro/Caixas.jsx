import React from "react";

export default function Caixas() {
  return (
    <div>
      <h1>Caixas</h1>
      <p>Conteúdo da página Caixas.</p>
    </div>
  );
}
