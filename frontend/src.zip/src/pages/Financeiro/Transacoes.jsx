import React from "react";

export default function Transacoes() {
  return (
    <div>
      <h1>Transacoes</h1>
      <p>Conteúdo da página Transacoes.</p>
    </div>
  );
}
