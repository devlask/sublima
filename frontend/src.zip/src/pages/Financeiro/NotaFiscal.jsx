import React from "react";

export default function NotaFiscal() {
  return (
    <div>
      <h1>NotaFiscal</h1>
      <p>Conteúdo da página NotaFiscal.</p>
    </div>
  );
}
