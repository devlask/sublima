export default function Configuracoes() {
    return (
      <div className="p-6 ml-64 mt-16">
        <h2 className="text-2xl font-bold mb-4">Configurações</h2>
        <p className="text-gray-700">Configurações gerais do sistema.</p>
      </div>
    );
  }
  