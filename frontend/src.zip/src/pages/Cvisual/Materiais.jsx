import React from "react";

export default function Materiais() {
  return (
    <div>
      <h1>Materiais</h1>
      <p>Conteúdo da página Materiais.</p>
    </div>
  );
}
