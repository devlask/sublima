import React from "react";

export default function Processos() {
  return (
    <div>
      <h1>Processos</h1>
      <p>Conteúdo da página Processos.</p>
    </div>
  );
}
