import React from "react";

export default function Produtos() {
  return (
    <div>
      <h1>Produtos</h1>
      <p>Conteúdo da página Produtos.</p>
    </div>
  );
}
