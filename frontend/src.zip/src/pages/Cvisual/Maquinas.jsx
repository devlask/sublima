import React from "react";

export default function Maquinas() {
  return (
    <div>
      <h1>Maquinas</h1>
      <p>Conteúdo da página Maquinas.</p>
    </div>
  );
}
