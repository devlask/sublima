import React from "react";

export default function Insumos() {
  return (
    <div>
      <h1>Insumos</h1>
      <p>Conteúdo da página Insumos.</p>
    </div>
  );
}
