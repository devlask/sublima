import React from "react";

export default function Papeis() {
  return (
    <div>
      <h1>Papeis</h1>
      <p>Conteúdo da página Papeis.</p>
    </div>
  );
}
