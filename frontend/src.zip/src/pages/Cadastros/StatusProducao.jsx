import React from "react";

export default function StatusProducao() {
  return (
    <div>
      <h1>StatusProducao</h1>
      <p>Conteúdo da página StatusProducao.</p>
    </div>
  );
}
