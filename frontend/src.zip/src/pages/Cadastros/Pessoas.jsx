import React from "react";

export default function Pessoas() {
  return (
    <div>
      <h1>Pessoas</h1>
      <p>Conteúdo da página Pessoas.</p>
    </div>
  );
}
