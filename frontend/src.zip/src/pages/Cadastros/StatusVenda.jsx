import React from "react";

export default function StatusVenda() {
  return (
    <div>
      <h1>StatusVenda</h1>
      <p>Conteúdo da página StatusVenda.</p>
    </div>
  );
}
