import React from "react";

export default function EstagiosVenda() {
  return (
    <div>
      <h1>EstagiosVenda</h1>
      <p>Conteúdo da página EstagiosVenda.</p>
    </div>
  );
}
