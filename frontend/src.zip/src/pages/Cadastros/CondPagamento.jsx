import React from "react";

export default function CondPagamento() {
  return (
    <div>
      <h1>CondPagamento</h1>
      <p>Conteúdo da página CondPagamento.</p>
    </div>
  );
}
