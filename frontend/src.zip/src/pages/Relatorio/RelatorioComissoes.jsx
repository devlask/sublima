import React from "react";

export default function RelatorioComissoes() {
  return (
    <div>
      <h1>RelatorioComissoes</h1>
      <p>Conteúdo da página RelatorioComissoes.</p>
    </div>
  );
}
