import React from "react";

export default function LogsAcesso() {
  return (
    <div>
      <h1>LogsAcesso</h1>
      <p>Conteúdo da página LogsAcesso.</p>
    </div>
  );
}
