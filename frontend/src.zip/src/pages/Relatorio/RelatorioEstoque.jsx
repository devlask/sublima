import React from "react";

export default function RelatorioEstoque() {
  return (
    <div>
      <h1>RelatorioEstoque</h1>
      <p>Conteúdo da página RelatorioEstoque.</p>
    </div>
  );
}
