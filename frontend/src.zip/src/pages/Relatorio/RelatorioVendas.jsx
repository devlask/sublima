import React from "react";

export default function RelatorioVendas() {
  return (
    <div>
      <h1>RelatorioVendas</h1>
      <p>Conteúdo da página RelatorioVendas.</p>
    </div>
  );
}
