// src/pages/Vendas/Pedidos.jsx
export default function Pedidos() {
    return (
      <div>
        <h1 className="text-2xl font-bold mb-4">Pedidos</h1>
        <p>Gerencie os pedidos dos clientes aqui.</p>
      </div>
    );
  }