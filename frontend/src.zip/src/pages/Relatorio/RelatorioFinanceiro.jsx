import React from "react";

export default function RelatorioFinanceiro() {
  return (
    <div>
      <h1>RelatorioFinanceiro</h1>
      <p>Conteúdo da página RelatorioFinanceiro.</p>
    </div>
  );
}
