import React from "react";

export default function Compras() {
  return (
    <div>
      <h1>Compras</h1>
      <p>Conteúdo da página Compras.</p>
    </div>
  );
}
