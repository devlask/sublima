import React from "react";

export default function Estoque() {
  return (
    <div>
      <h1>Estoque</h1>
      <p>Conteúdo da página Estoque.</p>
    </div>
  );
}
