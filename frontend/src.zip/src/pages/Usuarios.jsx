export default function Usuarios() {
    return (
      <div className="p-6 ml-64 mt-16">
        <h2 className="text-2xl font-bold mb-4">Usuários</h2>
        <p className="text-gray-700">Lista de usuários será exibida aqui.</p>
      </div>
    );
  }
  