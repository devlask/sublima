import React from "react";

export default function PDV() {
  return (
    <div>
      <h1>PDV</h1>
      <p>Conteúdo da página PDV.</p>
    </div>
  );
}
