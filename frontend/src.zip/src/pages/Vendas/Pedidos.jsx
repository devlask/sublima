import React, { useEffect, useState } from "react";
import axios from "axios";
import ModalAdicionarProduto from '../../components/ModalAdicionarProduto'; // ajuste o caminho se estiver em outra pasta


export default function PedidoListaCompleta() {
  const [pedidos, setPedidos] = useState([]);
  const [mostrarModal, setMostrarModal] = useState(false);
  const [pedidoSelecionado, setPedidoSelecionado] = useState(null);



  useEffect(() => {
    axios.get("http://localhost:5000/api/pedidos")
      .then(res => setPedidos(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="w-full bg-white rounded-md shadow text-sm font-sans">
      {/* Filtros e Header */}
      <div className="flex flex-wrap items-center gap-2 p-2 border-b bg-[#f5f7fa]">
        <button className="text-blue-600 px-2 py-1">📋 Lista</button>
        <button className="text-gray-600 px-2 py-1">🚚 Entrega Fracionada</button>
        <button className="text-gray-600 px-2 py-1">📌 Tarefas</button>
        <div className="ml-auto flex gap-2 items-center">
          <input className="border rounded px-2 py-1" placeholder="Cliente" />
          <input className="border rounded px-2 py-1" placeholder="Pesquisar" />
          <select className="border rounded px-2 py-1">
            <option>Status</option>
          </select>
          <button className="bg-blue-500 text-white px-2 py-1 rounded">+ Novo Pedido</button>
          <button className="bg-red-500 text-white px-2 py-1 rounded">🗑️</button>
        </div>
      </div>

      {/* Lista de Pedidos */}
      <div className="divide-y">
        {pedidos.map((pedido) => (
          <div key={pedido.id} className="bg-white">
            {/* Cabeçalho do Pedido */}
            <div className="flex items-center gap-2 px-2 py-1">
              <input type="checkbox" />
              <span className="w-12 text-center text-xs bg-gray-100 rounded px-1">{pedido.id}</span>
              <select
                className={`rounded px-2 py-1 text-white text-xs ${
                  pedido.status === "Aguardando"
                    ? "bg-indigo-500"
                    : pedido.status === "Entregue"
                    ? "bg-green-600"
                    : pedido.status === "Arte"
                    ? "bg-orange-500"
                    : "bg-blue-600"
                }`}
              >
                <option>{pedido.status}</option>
              </select>
              <span className="text-xs">{new Date(pedido.createdAt).toLocaleDateString()}</span>
              <span className="text-xs font-bold">{pedido.cliente}</span>
              <span className="text-xs ml-auto">{new Date(pedido.dataEntrega).toLocaleDateString()}</span>
              <span className="text-xs">⚙️ 📦 📑 🖨️</span>
              <span className="text-teal-600 bg-teal-100 rounded px-2 py-1 text-xs ml-2">
                R$ {parseFloat(pedido.valorTotal).toFixed(2)}
              </span>
              <button className="rounded-full bg-gray-200 w-6 h-6 ml-2">👤</button>
              <button className="text-blue-600 ml-1">✏️</button>
              <button className="text-gray-600 ml-1">🔍</button>
              <button className="text-gray-600 ml-1">⋮</button>
            </div>

            {/* Itens do Pedido — ainda fixos por enquanto */}
            {mostrarModal && (
    <ModalAdicionarProduto
      pedidoId={pedidoSelecionado}
      onClose={() => setMostrarModal(false)}
      onProdutoAdicionado={() => {/* Atualizar lista de pedidos se quiser */}}
    />
  )}

            <div className="px-10 py-2 bg-gray-50 border-t">
              <div className="flex items-center gap-2 py-1">
                <span className="rounded-full text-xs px-2 py-1 text-white bg-indigo-500">{pedido.status}</span>
                <span className="text-xs text-gray-700">Produto Exemplo</span>
                <button onClick={() => { setPedidoSelecionado(pedido.id); setMostrarModal(true); }}>
  ➕ Adicionar Produto
</button>
                <span className="text-xs">5</span>
                <span className="text-xs text-teal-700">R$ 76,00</span>
                <span className="text-xs text-teal-700">R$ {parseFloat(pedido.valorTotal).toFixed(2)}</span>
                <button className="text-blue-600 text-xs">✏️</button>
                <button className="text-gray-600 text-xs">🔍</button>
                <button className="text-gray-600 text-xs">⋮</button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Rodapé */}
      <div className="flex items-center justify-between border-t px-4 py-2 text-xs">
        <span className="font-semibold">
          Total de Pedidos: {pedidos.length}
        </span>
        <div className="flex items-center gap-1">
          <select className="border rounded px-1 py-0.5 text-xs">
            <option>10</option>
            <option>20</option>
          </select>
          <button className="px-1">«</button>
          <button className="px-1">‹</button>
          <span className="border px-2 rounded text-blue-600">1</span>
          <button className="px-1">›</button>
          <button className="px-1">»</button>
        </div>
      </div>
    </div>
  );
}


