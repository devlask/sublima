import React from "react";

export default function Tarefas() {
  return (
    <div>
      <h1>Tarefas</h1>
      <p>Conteúdo da página Tarefas.</p>
    </div>
  );
}
