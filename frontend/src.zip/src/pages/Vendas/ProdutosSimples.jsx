import React from "react";

export default function ProdutosSimples() {
  return (
    <div>
      <h1>ProdutosSimples</h1>
      <p>Conteúdo da página ProdutosSimples.</p>
    </div>
  );
}
