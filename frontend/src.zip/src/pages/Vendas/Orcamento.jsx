import React from "react";

export default function Orcamento() {
  return (
    <div>
      <h1>Orcamento</h1>
      <p>Conteúdo da página Orcamento.</p>
    </div>
  );
}
