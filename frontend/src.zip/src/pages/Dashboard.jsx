import { useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  FaTruck,
  FaBoxOpen,
  FaClipboardCheck,
  FaTools,
  FaPaintBrush,
  FaFolder,
  FaTimes,
  FaHandshake,
} from "react-icons/fa";

const dataPedidos = [
  { name: "Jun", offset: 0, visual: 0 },
  { name: "Jul", offset: 0, visual: 0 },
  { name: "Ago", offset: 1, visual: 2 },
  { name: "Set", offset: 2, visual: 3 },
  { name: "Out", offset: 0, visual: 0 },
  { name: "Nov", offset: 0, visual: 0 },
  { name: "Dez", offset: 0, visual: 0 },
  { name: "Jan", offset: 0, visual: 0 },
  { name: "Fev", offset: 0, visual: 0 },
  { name: "Mar", offset: 0, visual: 0 },
  { name: "Abr", offset: 0, visual: 0 },
  { name: "Mai", offset: 0, visual: 1 },
];

const dataOrcamentos = [
  { name: "Jun", offset: 0 },
  { name: "Jul", offset: 0 },
  { name: "Ago", offset: 2 },
  { name: "Set", offset: 1 },
  { name: "Out", offset: 0 },
  { name: "Nov", offset: 0 },
  { name: "Dez", offset: 0 },
  { name: "Jan", offset: 0 },
  { name: "Fev", offset: 0 },
  { name: "Mar", offset: 0 },
  { name: "Abr", offset: 0 },
  { name: "Mai", offset: 0 },
];

const COLORS = ["#28a745", "#e0e0e0"];

export default function Dashboard() {
  const [margem, setMargem] = useState(0);
  const meta = 50000;

  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Margem de contribuição */}
        <div className="bg-white p-4 rounded shadow col-span-1 flex flex-col items-center">
          <h2 className="text-sm mb-2">Margem Contribuição (mês)</h2>
          <PieChart width={160} height={160}>
            <Pie
              data={[{ value: margem }, { value: meta - margem }]}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={70}
              startAngle={90}
              endAngle={-270}
              dataKey="value"
            >
              {COLORS.map((color, index) => (
                <Cell key={`cell-${index}`} fill={color} />
              ))}
            </Pie>
          </PieChart>
          <p className="text-2xl font-bold">R$ {margem.toFixed(2)}</p>
          <p className="text-gray-500 text-sm">Meta: R$ {meta.toLocaleString()}</p>
        </div>

        {/* Gráfico de pedidos */}
        <div className="bg-white p-4 rounded shadow col-span-2">
          <h2 className="text-sm mb-2">Pedidos</h2>
          <ResponsiveContainer width="100%" height={150}>
            <AreaChart data={dataPedidos}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Area type="monotone" dataKey="offset" stackId="1" stroke="#8884d8" fill="#8884d8" />
              <Area type="monotone" dataKey="visual" stackId="1" stroke="#82ca9d" fill="#82ca9d" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Cards de status dos pedidos */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-4">
        <StatusCard icon={<FaFolder />} label="Aguardando" count={1} color="bg-indigo-600" />
        <StatusCard icon={<FaPaintBrush />} label="Arte" count={1} color="bg-orange-400" />
        <StatusCard icon={<FaTools />} label="Produção" count={1} color="bg-blue-500" />
        <StatusCard icon={<FaClipboardCheck />} label="Finalizado" count={0} color="bg-green-700" />
        <StatusCard icon={<FaBoxOpen />} label="Expedição" count={0} color="bg-blue-700" />
        <StatusCard icon={<FaTruck />} label="Entregue" count={1} color="bg-teal-600" />
        <StatusCard icon={<FaTimes />} label="Cancelado" count={0} color="bg-red-400" />
      </div>

      {/* Gráfico de orçamentos */}
      <div className="bg-white p-4 rounded shadow">
        <h2 className="text-sm mb-2">Orçamentos</h2>
        <ResponsiveContainer width="100%" height={150}>
          <AreaChart data={dataOrcamentos}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Area type="monotone" dataKey="offset" stroke="#8884d8" fill="#8884d8" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Cards de status dos orçamentos */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-4 gap-4">
        <StatusCard icon={<FaFolder />} label="Novo Orçamento" count={4} color="bg-indigo-600" />
        <StatusCard icon={<FaHandshake />} label="Em Negociação" count={0} color="bg-green-700" />
        <StatusCard icon={<FaClipboardCheck />} label="Aprovado" count={2} color="bg-teal-600" />
        <StatusCard icon={<FaTimes />} label="Cancelado" count={0} color="bg-red-400" />
      </div>
    </div>
  );
}

function StatusCard({ icon, label, count, color }) {
  return (
    <div className={`flex items-center gap-2 p-4 rounded shadow text-white ${color}`}>
      <div className="text-2xl">{icon}</div>
      <div>
        <div className="text-xl font-bold">{count}</div>
        <div className="text-sm uppercase">{label}</div>
      </div>
    </div>
  );
}
