import {
    FaCashRegister,
    FaBoxes,
    FaPrint,
    FaList,
    FaFileAlt,
    FaChartBar,
  } from "react-icons/fa";
  
  export const sidebarData = [
    {
      title: "Dashboard",
      icon: FaCashRegister,
      path: "/dashboard", // ou "/" se for a rota raiz
    },
    {
      title: "Vendas",
      icon: FaCashRegister,
      submenu: [
        { title: "Orçamento", path: "Vendas/orcamento" },
        { title: "Pedidos", path: "Vendas/pedidos" },
        { title: "Produtos Simples", path: "Vendas/produtos-simples" },
        { title: "PDV", path: "pdv/SelecionarCaixa" },
        { title: "Tarefas", path: "Vendas/tarefas" },
      ],
    },
    {
      title: "Financeiro",
      icon: FaFileAlt,
      submenu: [
        { title: "Transações", path: "Financeiro/transacoes" },
        { title: "Nota Fiscal", path: "Financeiro/nota-fiscal" },
        { title: "Caixas PDV", path: "Financeiro/caixas" },
      ],
    },
    {
      title: "Estoque",
      icon: FaBoxes,
      submenu: [
        { title: "Compras", path: "Estoque/compras" },
        { title: "Estoque", path: "Estoque/estoque" },
      ],
    },
    {
      title: "Comunicação Visual",
      icon: FaPrint,
      submenu: [
        { title: "Insumos", path: "Cvisual/insumos" },
        { title: "Máquinas", path: "Cvisual/maquinas" },
        { title: "Processos", path: "Cvisual/processos" },
        { title: "Materiais", path: "Cvisual/materiais" },
        { title: "Papéis", path: "Cvisual/papeis" },
        { title: "Produtos", path: "Cvisual/produtos" },
      ],
    },
    {
      title: "Cadastros",
      icon: FaList,
      submenu: [
        { title: "Status de Venda", path: "Cadastros/status-venda" },
        { title: "Estágios de Venda", path: "Cadastros/estagios-venda" },
        { title: "Status de Produção", path: "Cadastros/status-producao" },
        { title: "Pessoas", path: "Cadastros/pessoas" },
        { title: "Cond. Pagamento", path: "Cadastros/cond-pagamento" },
      ],
    },
    {
      title: "Relatórios",
      icon: FaChartBar,
      submenu: [
        { title: "Financeiro", path: "relatorio/relatorio-financeiro" },
        { title: "Vendas", path: "relatorio/relatorio-vendas" },
        { title: "Comissões", path: "relatorio/relatorio-comissoes" },
        { title: "Estoque", path: "relatorio/relatorio-estoque" },
        { title: "Logs de Acesso", path: "relatorio/logs-acesso" },
      ],
    },
  ];
  